clear;
load('data.mat');
data{1} = training00;
data{2} = training01;
data{3} = training02;
data{4} = training03;
data{5} = training04;
gamma = [10,1,0.1,0.01,0.001,0.0001];
C = [10,1,0.1,0.01,0.001,0.0001];
for i = 1:5
  dataTrain = [data{mod(i,5)+1};data{mod(i+1,5)+1};data{mod(i+2,5)+1};data{mod(i+3,5)+1}];
  dataTest = data{i};
  for j = 1:length(gamma)
      [w ,b ,errors] = simplePerceptron(dataTrain, learningRate(j),10);
      wAnswer1{j,i} = w;
      bAnswer1{j,i} = b;
      eAnswer1{j,i} = errors;
      correctRate1{j,i} = checkPerceptron(dataTest, w,b)/1658;
  end
  for j = 1:3
      [w ,b ,errors] = dynamicPerceptron(dataTrain, learningRate(j),10);
      wAnswer2{j,i} = w;
      bAnswer2{j,i} = b;
      eAnswer2{j,i} = errors;
      correctRate2{j,i} = checkPerceptron(dataTest, w,b)/1658;
  end
  for j = 1:3
      for n = 1:3
          [w ,b ,errors] = marginPerceptron(dataTrain, learningRate(j), margin(n),10);
          wMarginAnswer{(j-1)*3+n,i} = w;
          bMarginAnswer{(j-1)*3+n,i} = b;
          eMarginAnswer{(j-1)*3+n,i} = errors;
          correctRateMargin{(j-1)*3+n,i} = checkPerceptron(dataTest, w,b)/1658;
      end
  end
  for j = 1:3
      [w ,b ,errors] = averagePerceptron(dataTrain, learningRate(j),10);
      wAnswer4{j,i} = w;
      bAnswer4{j,i} = b;
      eAnswer4{j,i} = errors;
      correctRate4{j,i} = checkPerceptron(dataTest, w,b)/1658;
  end
    for p = 1:3
        correctRate1{p,6} = (correctRate1{p,1}+correctRate1{p,2}+correctRate1{p,3}+correctRate1{p,4}+correctRate1{p,5})/5;
        correctRate2{p,6} = (correctRate2{p,1}+correctRate2{p,2}+correctRate2{p,3}+correctRate2{p,4}+correctRate2{p,5})/5;
        correctRate4{p,6} = (correctRate4{p,1}+correctRate4{p,2}+correctRate4{p,3}+correctRate4{p,4}+correctRate4{p,5})/5;
    end
    for p = 1:9
        correctRateMargin{p,6} = (correctRateMargin{p,1}+correctRateMargin{p,2}+correctRateMargin{p,3}+correctRateMargin{p,4}+correctRateMargin{p,5})/5;
    end
end


disp("The accuracy of different leanring rate in simple perceptron");
disp(correctRate1);
disp("The Weight of different leanring rate in simple perceptron");
disp(wAnswer1);
disp("The bias of different leanring rate in simple perceptron");
disp(bAnswer1);
disp("The update times of different leanring rate in simple perceptron");
disp(eAnswer1);
disp("The accuracy of different leanring rate in dynamic perceptron");
disp(correctRate2);
disp("The Weight of different leanring rate in dynamic perceptron");
disp(wAnswer2);
disp("The bias of different leanring rate in dynamic perceptron");
disp(bAnswer2);
disp("The update times of different leanring rate in dynamic perceptron");
disp(eAnswer2);
disp("The accuracy of different leanring rate in margin perceptron");
disp(correctRateMargin);
disp("The Weight of different leanring rate in margin perceptron");
disp(wMarginAnswer);
disp("The bias of different leanring rate in margin perceptron");
disp(bMarginAnswer);
disp("The update times of different leanring rate in margin perceptron");
disp(eMarginAnswer);
disp("The accuracy of different leanring rate in average perceptron");
disp(correctRate4);
disp("The Weight of different leanring rate in average perceptron");
disp(wAnswer4);
disp("The bias of different leanring rate in average perceptron");
disp(bAnswer4);
disp("The update times of different leanring rate in average perceptron");
disp(eAnswer4);

