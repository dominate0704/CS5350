The code has been executed on CADE machine Lab2-34 and uses Matlab R2017a
Execution directory --- /home/yuchengy/CS5350/MATLAB/A5

This directory contains -
1. All the function script to reform the data.
2. Shell script 'run.sh' used to run the program. 
3. All the data sets.

To execute the program, execute the run.sh script. 
./run.sh
