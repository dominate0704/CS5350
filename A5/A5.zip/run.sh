


#!/bin/bash
matlab -nodisplay -nodesktop -r "run main.m"

