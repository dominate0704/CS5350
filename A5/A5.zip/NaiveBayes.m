function  w  = NaiveBayes( data, gamma, C ,epoch)
w = zeros(1,70000);
len = length(data);
for t = 1:epoch
    data = data(randperm(end));
    for i = 1:len
        x = data(i).line;
        x_len = length(x);
        x_new = zeros(70000,1);
        y = x(1);
        if x_len >1
            for j = 2:x_len
                x_new(x(j)) = 1;     
            end
        end
        if y*w*x_new <= 1
            w = (1-gamma)*w+gamma*C*y*x_new';
        else
            w = (1-gamma)*w;
        end
    end
end
end