The code has been executed on CADE machine Lab2-11 and uses Matlab R2017a
Execution directory --- /home/yuchengy/CS5350/A1

This directory contains -
1. All the function script to reform the data.
2. Shell script 'run.sh' used to run the program. As there are two script each for Q1 and Q2, so run the shell script will run the first script, 
then quit the matlab will run the second the script 
3. All the data sets.

To execute the program, execute the run.sh script. 
./run.sh
