


#!/bin/bash
matlab -nodisplay -nodesktop -r "run prior.m"
matlab -nodisplay -nodesktop -r "run cross_valid.m"
