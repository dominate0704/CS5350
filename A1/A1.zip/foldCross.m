function Validation =  foldCross(Data1, Data2, Data3, depth)
end
